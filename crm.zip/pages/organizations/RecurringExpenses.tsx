import React from 'react'

const RecurringExpenses = () => {
  return (
    <>
     <div className="container">
        <div className="row">
            <div className="col-12">
                <h2>
                RecurringExpenses
                </h2>
            </div>
        </div>
     </div>
    </>
  )
}

export default RecurringExpenses
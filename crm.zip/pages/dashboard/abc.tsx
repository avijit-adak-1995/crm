import React from 'react'

const abc = () => {
  return (
    <div>abc</div>
  )
}

export default abc
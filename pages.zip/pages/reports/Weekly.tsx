import React from 'react'

const Weekly = () => {
  return (
    <>
     <div className="container">
        <div className="row">
            <div className="col-12">
                <h2>Weekly</h2>
            </div>
        </div>
     </div>
    </>
  )
}

export default Weekly
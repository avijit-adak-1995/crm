import React from 'react'

const Documents = () => {
  return (
    <>
     <div className="container">
        <div className="row">
            <div className="col-12">
                <h2>Documents</h2>
            </div>
        </div>
     </div>
    </>
  )
}

export default Documents
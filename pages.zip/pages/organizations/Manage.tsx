import React from 'react'

const Manage = () => {
  return (
    <> 
     <div className="container">
        <div className="row">
            <div className="col-12">
                <h2>Manage</h2>
            </div>
        </div>
     </div>
    </>
  )
}

export default Manage
import React from 'react'

const ProposalTemplate = () => {
  return (
    <>
      <div className="container">
        <div className="row">
            <div className="col-12">
                <h2>ProposalTemplate</h2>
            </div>
        </div>
      </div>
    </>
  )
}

export default ProposalTemplate
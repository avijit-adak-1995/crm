export default function MainLayout({ children }: any) {
    return (
        <div>
            
            <main>{children}</main>
          
        </div>
    );
}